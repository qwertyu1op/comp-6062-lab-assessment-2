# comp-6062-lab-assessment-2
 Lab Assesment 2 for JS
